Examples were developed against the first driver release on 2015-04-13
